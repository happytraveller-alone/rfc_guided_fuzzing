1. 安装rust
2. cargo test 查看代码是否有语法错误
3. cargo run 运行
4. cargo run -- --use_guide ： 使用说明
